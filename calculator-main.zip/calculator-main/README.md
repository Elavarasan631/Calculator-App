# Simple calculator built using Flutter and Dart

**_Follow the below steps to preview the app in project idx_**

* Open any browser and visit Project IDx <https://idx.dev>

* Click on import a repo and paste the below repo link
  
``` 
https://github.com/WebX-Divin/calculator.git
```

* Also click on `This is a flutter app` and then import the repository

* This is how it looks once it is opened in Project IDx

  
![Simple Calculator Demo in Project IDx](https://github.com/user-attachments/assets/5c26c336-863d-4fe0-9591-422714c4a18f)
